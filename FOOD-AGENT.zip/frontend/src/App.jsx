import React from "react";
import ChatContainer from "./component/ChatContainer";

export default function App() {
    return <ChatContainer />;
}
